'use strict';
const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
  class Tables extends Model {
    static associate(models) {
      Tables.hasMany(models.Orders,  { foreignKey: 'tableId' });
      Tables.belongsTo(models.Branch, { foreignKey: 'branchId', as: 'branch' });
    }
  }

  Tables.init(
    {
      id: {
        allowNull: false,
        autoIncrement: true,
        primaryKey: true,
        type: DataTypes.INTEGER,
      },
      tableNumber: {
        type: DataTypes.INTEGER,
        allowNull: false,
        field: 'table_number',
      },
      capacity: {
        type: DataTypes.INTEGER,
        allowNull: false,
        defaultValue: 4,
      },
      branchId: {
        type: DataTypes.INTEGER,
        field: 'branch_id',
        allowNull: true,
      },
    },
    {
      sequelize,
      tableName: 'tables',
      modelName: 'Tables',
    }
  );

  return Tables;
};
