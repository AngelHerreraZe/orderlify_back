'use strict';
const userRoutes        = require('./users.routes');
const rolesRoutes       = require('./roles.routes');
const productsRoutes    = require('./products.routes');
const tablesRoutes      = require('./tables.routes');
const ordersRoutes      = require('./orders.routes');
const paymentsRoutes    = require('./payments.route');
const adminRoutes       = require('./admin.routes');
const companyInfoRoutes = require('./companyInfo.routes');
const branchesRoutes    = require('./branches.routes');
const stationsRoutes      = require('./stations.routes');
const cashRegisterRoutes  = require('./cashRegister.routes');
const usersSyncRoutes     = require('./usersSync.routes');

const ApiRoutes = (app) => {
  app.use('/api/v1/', userRoutes);
  app.use('/api/v1/', rolesRoutes);
  app.use('/api/v1/', productsRoutes);
  app.use('/api/v1/', tablesRoutes);
  app.use('/api/v1/', ordersRoutes);
  app.use('/api/v1/', paymentsRoutes);
  app.use('/api/v1/', adminRoutes);
  app.use('/api/v1/', companyInfoRoutes);
  app.use('/api/v1/', branchesRoutes);
  app.use('/api/v1/', stationsRoutes);
  app.use('/api/v1/', cashRegisterRoutes);
  app.use('/api/v1/', usersSyncRoutes);
};

module.exports = ApiRoutes;
